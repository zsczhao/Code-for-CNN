from data_function import *
dataset(7,301,train_or_test='train',t1=4,k1=35)
datamaker(test_or_train='train')

dataset(100,301,train_or_test='test',t1=4,k1=35)
datamaker(test_or_train='test')
